CREATE TABLE book_details(
                             book_id INT PRIMARY KEY  AUTO_INCREMENT,
                             NAME VARCHAR(255),
                             book_desc TEXT,
                             publisher VARCHAR(255),
                             author VARCHAR(255)
)