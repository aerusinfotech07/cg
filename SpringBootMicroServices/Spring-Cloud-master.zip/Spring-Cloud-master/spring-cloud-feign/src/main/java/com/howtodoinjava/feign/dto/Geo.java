package com.howtodoinjava.feign.dto;

public record Geo(String lat,
                  String lng) {

}
