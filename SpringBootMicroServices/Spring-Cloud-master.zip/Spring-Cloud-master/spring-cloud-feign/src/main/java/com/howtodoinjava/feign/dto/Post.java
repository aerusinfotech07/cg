package com.howtodoinjava.feign.dto;

public record Post(Long userId,
                   Long id,
                   String title,
                   String body) {

}
