package com.howtodoinjava.feign.dto;

public record Company(String name,
                      String catchPhrase,
                      String bs) {
}
