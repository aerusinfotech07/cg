package com.gozde.dockercomposedemo.model.dto;

import lombok.Data;

@Data
public class CreateCustomerDto {

    private String firstName;

    private String lastName;

}
