package com.safalifter.authservice.enums;

public enum Role {
    ADMIN, USER
}
