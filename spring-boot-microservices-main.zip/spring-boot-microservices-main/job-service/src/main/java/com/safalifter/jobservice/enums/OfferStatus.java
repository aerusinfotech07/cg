package com.safalifter.jobservice.enums;

public enum OfferStatus {
    OPEN, CLOSED, ACCEPTED, REJECTED
}
