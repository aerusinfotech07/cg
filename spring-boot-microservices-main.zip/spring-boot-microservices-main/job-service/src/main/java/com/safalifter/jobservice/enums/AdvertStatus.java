package com.safalifter.jobservice.enums;

public enum AdvertStatus {
    OPEN, CLOSED, CANCELLED, ASSIGNED, REVIEWED
}
