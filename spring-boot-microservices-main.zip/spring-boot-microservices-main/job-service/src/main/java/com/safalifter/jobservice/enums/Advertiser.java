package com.safalifter.jobservice.enums;

public enum Advertiser {
    EMPLOYEE, CUSTOMER
}
