package com.safalifter.userservice.enums;

public enum Role {
    ADMIN, USER
}
