package com.safalifter.userservice.enums;

public enum Active {
    ACTIVE, INACTIVE
}
