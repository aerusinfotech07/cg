
package com.cg.topic11.autoscanning.annotation.xml;

public class CustomerDAO 
{
	@Override
	public String toString() {
		return "Hello , This is CustomerDAO";
	}	
}
