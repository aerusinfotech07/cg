package com.cg.topic1.basic;

public class PrintPDF implements Printable {

	@Override
	public void print() {
		System.out.println("This will Print Data in Pdf Format");
		
	}

}
