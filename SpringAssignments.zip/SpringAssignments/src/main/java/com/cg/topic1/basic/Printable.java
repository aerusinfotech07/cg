package com.cg.topic1.basic;

public interface Printable {
	
	public void print();

}
