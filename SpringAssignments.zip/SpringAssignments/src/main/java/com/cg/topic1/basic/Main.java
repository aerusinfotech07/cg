package com.cg.topic1.basic;

public class Main {

	public static void main(String[] args) {
		HelloWorld helloWorld=new HelloWorld();
		helloWorld.setName("Ramesh");
		helloWorld.printHello();

	}

}
