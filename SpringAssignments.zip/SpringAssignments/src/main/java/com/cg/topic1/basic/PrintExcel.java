package com.cg.topic1.basic;

public class PrintExcel implements Printable {

	@Override
	public void print() {
		System.out.println("This will Print Data in Excel Format");
		
	}

}
