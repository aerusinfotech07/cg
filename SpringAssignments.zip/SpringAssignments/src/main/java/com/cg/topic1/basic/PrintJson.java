package com.cg.topic1.basic;

public class PrintJson implements Printable {

	@Override
	public void print() {
		System.out.println("This will Print Data in Json Format");
		
	}

}
