package com.cg.topic12.autowiring.xml;

public class Person {

}
