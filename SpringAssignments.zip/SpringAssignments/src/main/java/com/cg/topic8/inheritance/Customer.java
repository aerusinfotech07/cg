package com.cg.topic8.inheritance;

public class Customer {
	
	private int type;
	private String action;
	private String Country;

}
