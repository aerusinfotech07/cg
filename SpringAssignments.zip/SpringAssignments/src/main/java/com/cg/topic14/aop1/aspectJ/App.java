package com.cg.topic14.aop1.aspectJ;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new GenericXmlApplicationContext(
                new FileSystemResource("src/main/java/com/cg/topic14/aop1/aspectJ/Spring-Customer.xml"));
        
		CustomerBo customer = (CustomerBo) context.getBean("customerBo");
		customer.addCustomer();
		
		//customer.addCustomerReturnValue();
		
		//customer.addCustomerThrowException();
		
		customer.addCustomerAround("cg");
    	
    }
}