package com.cg.topic2.config.importmultiple;

public class CustomerBo {

	public void printMsg(String msg) {

		System.out.println("CustomerBo : " + msg);
	}

}
