package com.cg.topic2.config.importmultiple;

public class SchedulerBo {

	public void printMsg(String msg) {

		System.out.println("SchedulerBo : " + msg);
	}

}
