package com.cg.topic2.config;

public interface HelloWorld {
	
	void printHelloWorld(String msg);
 
}