package com.cg.topic9.dependencychecking;

public class Person {
	
	private String name;
	private String address;
	private int age;

}
