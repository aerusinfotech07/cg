package com.cg.topic9.dependencychecking;

public class Customer {
	
	private Person person;
	private int type;
	private String action;

}
