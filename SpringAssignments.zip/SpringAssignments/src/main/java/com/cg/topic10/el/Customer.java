package com.cg.topic10.el;

public class Customer {

	private Item item;

	private String itemName;

}