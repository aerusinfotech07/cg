package com.cg.topic10.el;


public class Item {

	private String name;

	private int qty;

}