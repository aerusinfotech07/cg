package com.cg.topic4.innerbean;

public class Company {
	
	
	private Person peerson;

}
