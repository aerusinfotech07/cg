package com.cg.topic3.di.setter;

public interface IOutputGenerator
{
	public void generateOutput();
}
