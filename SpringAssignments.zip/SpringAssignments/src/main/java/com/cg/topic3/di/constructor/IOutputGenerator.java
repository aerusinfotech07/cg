package com.cg.topic3.di.constructor;

public interface IOutputGenerator
{
	public void generateOutput();
}
