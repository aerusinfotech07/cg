package com.cg.topic7.placeholder;

import javax.sql.DataSource;

public class SimpleJdbcCustomerDAO {
	
	
	DataSource dataSource;

}
