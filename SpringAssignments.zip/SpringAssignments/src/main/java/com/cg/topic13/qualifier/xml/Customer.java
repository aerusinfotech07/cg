package com.cg.topic13.qualifier.xml;

public class Customer {

	private Item item;

	private String itemName;

}