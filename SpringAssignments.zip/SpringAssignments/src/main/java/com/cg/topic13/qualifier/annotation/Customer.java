package com.cg.topic13.qualifier.annotation;

public class Customer {

	private Item item;

	private String itemName;

}