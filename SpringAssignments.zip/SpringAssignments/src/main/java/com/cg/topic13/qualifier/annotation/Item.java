package com.cg.topic13.qualifier.annotation;


public class Item {

	private String name;

	private int qty;

}