package com.cg.topic13.qualifier.xml;


public class Item {

	private String name;

	private int qty;

}