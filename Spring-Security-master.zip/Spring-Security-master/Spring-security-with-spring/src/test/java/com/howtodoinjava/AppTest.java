package com.howtodoinjava;

/**
 * Unit test for simple App.
 */
public class AppTest {

}
